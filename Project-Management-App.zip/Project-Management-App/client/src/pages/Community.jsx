import React from 'react'

const Community = () => {
  return (
    <div>Comming Soon...</div>
  )
}

export default Community
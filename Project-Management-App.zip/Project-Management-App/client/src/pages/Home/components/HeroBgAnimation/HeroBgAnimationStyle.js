import styled from 'styled-components';


export const Div = styled.div`
    width: 500px;
    height: 500px;
`
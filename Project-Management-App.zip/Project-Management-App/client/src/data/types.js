const ITEM_TYPE = "ITEM";

export default ITEM_TYPE;